# -*- coding: utf-8 -*-
"""PDF -> 化学教案 转换器（Google Gemini 云端 API 版）。

与本地推理版 `pdf_to_chemistry_handout.py`（Qwen2-VL-7B 4-bit）的关系：
    * 相同的输入输出契约：PDF -> 按页分节的 Markdown 讲义；
    * 相同的提示词（PROMPT）与相同的确定性后处理（handout_normalize）；
    * 区别只在“看图”的那一步：这里把每页渲染成 JPEG 后调用 Gemini API，
      不再需要 GPU、不需要下载 15.5GB 权重、也不再受 8GB 显存的像素上限约束。

用法：
    python pdf_to_chemistry_handout_gemini.py [输入.pdf] [输出.md]
    python pdf_to_chemistry_handout_gemini.py --check          # 只测 API 连通性

依赖环境：任何一个 Python 3.10+ 环境，装齐这两个包即可（**不需要 torch / transformers /
bitsandbytes，也不需要 GPU**）：

    pip install google-genai pymupdf            # 还需要 Pillow（PyMuPDF 通常已带上）

本机的两个 conda 环境当前各缺一半，装齐后任选其一：

    conda activate Handout-Maker2   # 已有 pymupdf/Pillow，缺 google-genai
    pip install google-genai
    # 或者
    conda activate ai-assistant     # 已有 google-genai 2.7.0，缺 pymupdf/Pillow
    pip install pymupdf pillow

API Key 读取顺序：命令行 > 环境变量 GEMINI_API_KEY / GOOGLE_API_KEY > 脚本内兜底值。

先跑自检再批量转（尤其在国内网络下，见 README 里“区域限制”一节）：

    python pdf_to_chemistry_handout_gemini.py --check
"""

import argparse
import base64
import io
import os
import re
import struct
import sys
import tempfile
import time
import zlib

from handout_normalize import normalize_handout_markdown

# ---------------------------------------------------------------------------
# 1. 常量与默认配置
# ---------------------------------------------------------------------------
DEFAULT_API_KEY = "AQ.Ab8RN6KpxB4G_LYthSZ_dZ2t5byaj_CtndmwqButo6kFbOGAyA"

# 实测模型可用性（本机实测，同一个 API Key）：
#   gemini-2.5-flash  -> 模型存在（当前节点因区域限制被拒，见下）
#   gemini-2.0-flash  -> 404 "no longer available. Please update to models/gemini-3.6-flash"
#   gemini-1.5-*      -> 已全面停用
# 因此默认链为 2.5-flash 优先、3.6-flash 兜底。
#
# ⚠️ 区域限制（notebook 里那句“节点基本都被风控”说的就是它）：
#   本机经 127.0.0.1:7897 出口 IP 为美国加州某机房网段时，请求会返回
#       400 FAILED_PRECONDITION: "User location is not supported for the API use."
#   这**不是脚本或 Key 的问题**，而是该出口 IP 被 Google 判为不支持的地区。
#   换一个普通住宅/可用的节点后即可正常；`--check` 会把这类错误原样打出来。
DEFAULT_MODELS = ("gemini-2.5-flash", "gemini-3.6-flash")

# 渲染 DPI。Gemini 走网络传输，不像本地推理那样受显存限制，
# 但对“幻灯片正文”而言 150 DPI 已足够看清上下标；想更清晰可 --dpi 200。
RENDER_DPI = int(os.environ.get("HM_DPI", "150"))

# 每次请求塞几页图。Gemini 单请求总量上限约 20MB，
# 150 DPI + JPEG 后单页约 150~350KB，8 页留了充足余量。
PAGES_PER_REQUEST = int(os.environ.get("HM_PAGES_PER_REQUEST", "8"))

# 单图字节上限（超过就降质量、降分辨率重编码）
MAX_IMAGE_BYTES = int(os.environ.get("HM_MAX_IMAGE_BYTES", str(6 * 1024 * 1024)))

# 速率限制 / 临时故障的重试次数与退避基数（秒），指数退避 + 抖动。
MAX_RETRIES = int(os.environ.get("HM_MAX_RETRIES", "4"))
RETRY_BASE_DELAY = float(os.environ.get("HM_RETRY_BASE_DELAY", "5"))

# 单次请求最长等待（毫秒）。整页 Markdown + 长思考可能较慢，给足 5 分钟。
REQUEST_TIMEOUT_MS = int(os.environ.get("HM_REQUEST_TIMEOUT_MS", "300000"))

# 输出文档的标题后缀：`<PDF 文件名>` + 这个后缀作为一级标题。
_DEFAULT_TITLE_SUFFIX = " 课程讲义"


# ---------------------------------------------------------------------------
# 2. 提示词（与本地版逐字一致，仅追加“多页时用注释标记页序”一条）
# ---------------------------------------------------------------------------
PROMPT = """你是一个专业的化学讲义整理助手。请将这张化学课件图片的内容转换为结构化的 Markdown 讲义。
要求：
1. 提取所有文字标题、正文和列表，保留清晰的段落结构。
2. **所有化学式与化学方程式必须且只能使用同一种格式：行内 LaTeX（$...$）**。
   元素符号用 \\text{...} 保持正体，上下标用 _ 与 ^（例如 $\\text{H}_2\\text{O}$、$\\text{Fe}^{3+}$、$\\text{SO}_4^{2-}$）。
   禁止使用 Unicode 上下标（如 H₂O、Na⁺），禁止 \\ce{}，禁止 \\[...\\] 与 \\begin{align*} 等公式环境。
3. 化学方程式中的等号必须写作 =，**绝对禁止用 -> 或 → 代替等号**。
   只有带反应条件（加热、点燃、催化剂等）或可逆反应才用箭头：条件写 \\xrightarrow[下方条件]{上方条件}，可逆写 \\rightleftharpoons，
   气体/沉淀符号用 \\uparrow / \\downarrow。
   示例：$\\text{2KClO}_3 \\xrightarrow[\\Delta]{\\text{MnO}_2} \\text{2KCl} + \\text{3O}_2\\uparrow$；
   以及 $2\\text{Na} + 2\\text{H}_2\\text{O} = 2\\text{NaOH} + \\text{H}_2\\uparrow$。
4. 遇到图表或示意图，请在对应位置用 `>[图示: 描述内容]` 标记出提示。
5. 直接输出 Markdown 内容：不要用 ``` 代码块包裹，不要输出任何解释、总结或“请随时告诉我”之类的收尾语。"""

# 多图（一批多页）时追加的页序约定，便于按批请求时仍能还原页边界。
MULTI_IMAGE_PROMPT = PROMPT + """
6. 本次输入包含多张幻灯片图片，请严格按图片顺序逐页转写；
   在每页内容之前单独输出一行 `<!-- page: N -->`（N 为该图在本批中的序号，从 1 开始），
   除此之外不要添加任何其他注释。"""


# ---------------------------------------------------------------------------
# 3. 代理设置（照搬 verify_gemini_API.ipynb 的做法）
# ---------------------------------------------------------------------------
def setup_proxy(proxy=None):
    """设置 HTTP(S) 代理环境变量。

    notebook 里是写死 127.0.0.1:7897 的机场端口；这里改为“仅当显式传入时”才设置，
    因为 google-genai 底层是 httpx，httpx **默认 trust_env=True**，会自动读取
    http_proxy/https_proxy —— 不设置就等于直连，设置了就必然生效。
    """
    if proxy is None:
        proxy = os.environ.get("HM_PROXY") or None
    if not proxy:
        return None
    for name in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY"):
        os.environ[name] = proxy
    # 本地回环永远不走代理，避免把本地服务也绕出去。
    os.environ.setdefault("NO_PROXY", "localhost,127.0.0.1,::1")
    os.environ.setdefault("no_proxy", os.environ["NO_PROXY"])
    return proxy


# ---------------------------------------------------------------------------
# 4. 客户端构建与模型降级
# ---------------------------------------------------------------------------
def resolve_api_key(explicit=None):
    """API Key 解析：命令行 > 环境变量 > 脚本内兜底值。"""
    if explicit:
        return explicit
    for env in ("GEMINI_API_KEY", "GOOGLE_API_KEY"):
        if os.environ.get(env):
            return os.environ[env]
    return DEFAULT_API_KEY


def build_client(api_key=None, proxy=None):
    """构建 genai.Client，带超时、不自动重试（重试逻辑由本脚本显式控制）。"""
    from google import genai
    from google.genai import types

    setup_proxy(proxy)
    return genai.Client(
        api_key=resolve_api_key(api_key),
        http_options=types.HttpOptions(
            timeout=REQUEST_TIMEOUT_MS,
            retry_options=types.HttpRetryOptions(attempts=1),
        ),
    )


def parse_models(model_arg):
    """把 --model 参数（可逗号分隔）解析成降级链。"""
    if not model_arg:
        return list(DEFAULT_MODELS)
    models = [m.strip() for m in str(model_arg).split(",") if m.strip()]
    return models or list(DEFAULT_MODELS)


# ---------------------------------------------------------------------------
# 5. PDF 页面转 JPEG（同一套渲染链路，只是换掉输出格式）
# ---------------------------------------------------------------------------
def render_pdf_pages(pdf_path, dpi=RENDER_DPI, workdir=None, max_image_bytes=MAX_IMAGE_BYTES):
    """把 PDF 每页渲染成 JPEG，返回 ([(page_index, jpg_path), ...], workdir)。

    相比本地版多了一层“体积控制”：Gemini 请求是**整体上传**的，单请求总量约 20MB，
    所以这里在编码质量与分辨率上做自适应收缩（原图 -> q90 -> q75 -> q60 -> 0.75x ...），
    直到单图字节数落在 max_image_bytes 之内。
    """
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"找不到 PDF 文件: {pdf_path}")

    try:
        import pymupdf  # PyMuPDF >= 1.24 的新名字
    except ImportError:  # 老版本只有 fitz 别名
        import fitz as pymupdf

    from PIL import Image

    doc = pymupdf.open(pdf_path)
    workdir = workdir or tempfile.mkdtemp(prefix="hm_gemini_pages_")
    pages = []
    try:
        for page_num in range(len(doc)):
            pix = doc[page_num].get_pixmap(dpi=dpi)
            img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)

            scale = 1.0
            quality = 90
            while True:
                buf = io.BytesIO()
                out = img
                if scale < 1.0:
                    out = img.resize(
                        (max(1, int(img.width * scale)), max(1, int(img.height * scale))),
                        Image.LANCZOS,
                    )
                out.save(buf, format="JPEG", quality=quality, optimize=True)
                size = buf.tell()
                if size <= max_image_bytes or (quality <= 60 and scale <= 0.75):
                    break
                if quality > 60:
                    quality -= 15
                else:
                    scale *= 0.75

            img_path = os.path.join(workdir, f"page_{page_num}.jpg")
            with open(img_path, "wb") as f:
                f.write(buf.getvalue())
            pages.append((page_num, img_path))
            print(
                f"  渲染第 {page_num + 1} 页: {pix.width}x{pix.height} -> "
                f"{size / 1024:.0f}KB (q{quality}, scale={scale:.2f})",
                flush=True,
            )
    finally:
        doc.close()
    return pages, workdir


# ---------------------------------------------------------------------------
# 6. API 调用与错误分类
# ---------------------------------------------------------------------------
def _raw_bytes(data):
    """兼容两种形状：bytes（SDK 反序列化后的 Part）或 base64 str（wire 形状 dict）。"""
    if isinstance(data, (bytes, bytearray)):
        return bytes(data)
    return base64.b64decode(data)


def _part_payload(part):
    """从 contents 里的一个 part 取出内联图片字节（dict 形状 / SDK 对象都支持）。"""
    inline = part.get("inline_data") if isinstance(part, dict) else getattr(part, "inline_data", None)
    if inline is None:
        raise ValueError("contents 中存在不带 inline_data 的元素")
    data = inline.get("data") if isinstance(inline, dict) else inline.data
    return _raw_bytes(data)


def _image_part(path):
    """按 google-genai 的 wire 形状（camelCase + 嵌套 dict）描述一张内联图片。

    刻意不用 `types.Part.from_bytes(...)`：SDK 会把 dict 自动转成 Part，
    而 dict 形状让 `call_gemini` **不依赖任何 SDK 类型**，
    因此整条链路（重试/降级/切页/落盘）可以在没有 google-genai 的环境里被测试。
    """
    with open(path, "rb") as f:
        return {
            "inline_data": {
                "mime_type": "image/jpeg",
                "data": base64.b64encode(f.read()).decode("ascii"),
            }
        }


def _is_retryable(err):
    """区分“重试有用”的错误（限流/超时/服务端 5xx）与“重试无用”的错误（鉴权/参数/配额耗尽）。"""
    text = str(err).lower()
    retryable = (
        "429", "resource_exhausted", "rate limit", "quota exceeded",
        "500", "502", "503", "504", "internal", "unavailable",
        "deadline", "timeout", "timed out", "connection", "reset",
    )
    non_retryable = (
        "api key not valid", "invalid api key", "permission_denied",
        "unauthenticated", "401", "403", "not found", "404",
        "invalid argument", "400",
    )
    if any(k in text for k in non_retryable):
        return False
    return any(k in text for k in retryable)


def _build_config(temperature):
    """构造请求配置（纯 dict，同上：不依赖 SDK 类型）。"""
    safety = [
        {"category": cat, "threshold": "BLOCK_ONLY_HIGH"}
        for cat in (
            "HARM_CATEGORY_HARASSMENT",
            "HARM_CATEGORY_HATE_SPEECH",
            "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            "HARM_CATEGORY_DANGEROUS_CONTENT",
        )
    ]
    return {
        # 系统指令用来对抗“助手人格”：模型有强烈的“包一层代码块 / 补一句总结”倾向，
        # 提示词里已经写了一遍，这里再以最高优先级压一次（后处理还会兜底）。
        "system_instruction": (
            "你是化学课件转写引擎，只输出 Markdown 正文本身，"
            "不输出任何解释、寒暄、代码围栏或收尾语。"
        ),
        "temperature": temperature,   # 默认 0：转写任务要确定性，不要创造性
        "max_output_tokens": 8192,    # 一页 Markdown 通常远小于此，留足余量
        "safety_settings": safety,
    }


def call_gemini(client, models, image_paths, temperature=0.0, verbose=True):
    """调用 Gemini 完成一次（单页或多页）识别，返回 Markdown 文本。

    * 自动重试：限流/超时/5xx 走指数退避 + 抖动；
    * 自动降级：模型不存在或不可用时，切到 models 链里的下一个模型。
    """
    multi = len(image_paths) > 1
    prompt = MULTI_IMAGE_PROMPT if multi else PROMPT
    config = _build_config(temperature)

    contents = [_image_part(p) for p in image_paths] + [prompt]

    last_err = None
    for model in models:
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                if verbose:
                    print(f"  -> {model}（{len(image_paths)} 张图，第 {attempt} 次尝试）", flush=True)
                response = client.models.generate_content(
                    model=model, contents=contents, config=config
                )
                return extract_text(response)
            except Exception as e:  # noqa: BLE001 —— 需要按错误文本分类，故整体捕获
                last_err = e
                retryable = _is_retryable(e)
                detail = re.sub(r"\s+", " ", str(e))[:200]
                if not retryable:
                    # 鉴权/参数类错误：换模型也救不回来（除了 404 模型不存在）
                    model_missing = "404" in str(e) or "not found" in str(e).lower()
                    if not model_missing:
                        raise RuntimeError(f"{model} 调用失败（不可重试）: {detail}") from e
                    print(f"  !! {model} 不可用（{detail}），尝试下一个模型", flush=True)
                    break
                if attempt < MAX_RETRIES:
                    delay = RETRY_BASE_DELAY * (2 ** (attempt - 1))
                    delay += (zlib.crc32(str(e).encode()) % 1000) / 1000.0  # 抖动，避免同步重试
                    print(f"  !! 第 {attempt} 次失败（{detail}），{delay:.1f}s 后重试", flush=True)
                    time.sleep(delay)
                else:
                    print(f"  !! {model} 重试 {MAX_RETRIES} 次仍失败，尝试下一个模型", flush=True)
    raise RuntimeError(f"所有模型均调用失败，最后一个错误: {last_err}")


def extract_text(response):
    """从响应里取出文本，并对“空响应”给出可诊断的报错。

    云端 API 与本地 generate() 的差别之一：内容可能被安全策略拦掉，
    此时 response.text 会抛异常或返回 None —— 这种情况下静默写空段落是最坏的结果。
    """
    text = None
    try:
        text = response.text
    except Exception:  # noqa: BLE001
        text = None
    if not text:
        try:
            cand = response.candidates[0]
            finish = getattr(cand, "finish_reason", None)
            text = "".join(
                p.text for p in (cand.content.parts or []) if getattr(p, "text", None)
            )
            if not text:
                raise RuntimeError(f"响应为空，finish_reason={finish}")
        except RuntimeError:
            raise
        except Exception as e:  # noqa: BLE001
            raise RuntimeError(f"无法从响应中提取文本: {e}") from e
    return text


# ---------------------------------------------------------------------------
# 7. 按页/按批组织与页序还原
# ---------------------------------------------------------------------------
_PAGE_MARK_RE = re.compile(r"(?m)^[ \t]*(?:<!--\s*page\s*:\s*(\d+)\s*-->|#{1,6}\s*第\s*(\d+)\s*页[^\n]*)$")


def split_by_page_marks(text):
    """把一批多页的输出按 `<!-- page: N -->` 切回单页，返回 [(页码或 None, 正文), ...]。

    模型不总是乖乖打标记：**一个标记都没有**时退化为“整批作为一块返回”，
    绝不猜页序 —— 宁可标题里少几个分节，也不能把 A 页的内容挂到 B 页标题下。
    """
    marks = list(_PAGE_MARK_RE.finditer(text))
    if len(marks) < 2:
        return [(None, text)]

    blocks = []
    for i, m in enumerate(marks):
        start = m.end()
        end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
        num = m.group(1) or m.group(2)
        try:
            page_no = int(num)
        except (TypeError, ValueError):
            page_no = None
        blocks.append((page_no, text[start:end].strip()))
    return [b for b in blocks if b[1]] or [(None, text)]


def _page_heading(label):
    return f"## 第 {label} 页内容" if label else "## 内容"


def _assemble_blocks(text, batch, label, normalize):
    """把一批的模型输出切成 `_write_blocks` 用的三元组列表：[(页码或 None, 正文, 标签), ...]。

    ⚠️ 顺序很关键，这里踩过一次真实的坑：
    `handout_normalize` 第 5 步会把 `->` / `→` 一律还原成等号，
    而页序标记 `<!-- page: 2 -->` 里的 `-->` 正好命中这条规则，
    于是**先归一化再切页**会把标记破坏成 `<!-- page: 2 =`，切页直接失效
    （实测 15 页会被塞进 1 个分节里）。所以必须**先切页、再逐块归一化**。
    """
    if len(batch) == 1:
        blocks = [(batch[0][0] + 1, text)]
    else:
        blocks = [
            ((batch[0][0] + num) if num else None, body)
            for num, body in split_by_page_marks(text)
        ]

    if len(blocks) == 1 and len(batch) > 1:
        # 模型没按约定打 page 标记：页序无法确认，退化成整块 ——
        # 宁可少几个分节，也不能把 A 页的内容挂到 B 页标题下。
        # 标签写成页码范围，读者至少知道这一节包含哪几页。
        page_no, body = blocks[0]
        body = normalize_handout_markdown(body) if normalize else body
        return [(page_no, body, label)]

    return [
        (page_no, normalize_handout_markdown(body) if normalize else body, label)
        for page_no, body in blocks
    ]


def _write_blocks(f, blocks):
    """blocks 的元素是 (页码或 None, 正文, 标题兜底标签)。"""
    for page_no, body, label in blocks:
        heading = _page_heading(page_no) if page_no is not None else f"## 第 {label} 页内容"
        f.write(f"{heading}\n\n{body}\n\n---\n\n")


# ---------------------------------------------------------------------------
# 8. 主流程
# ---------------------------------------------------------------------------
def convert_pdf_to_handout(
    pdf_path,
    output_md_path,
    client=None,
    api_key=None,
    proxy=None,
    models=None,
    dpi=RENDER_DPI,
    pages_per_request=PAGES_PER_REQUEST,
    normalize=True,
    temperature=0.0,
):
    """PDF -> Markdown 讲义。与本地版同名的入口函数，便于把两者互换调用。"""
    if client is None:
        client = build_client(api_key=api_key, proxy=proxy)
    models = models or list(DEFAULT_MODELS)
    pages_per_request = max(1, int(pages_per_request))

    images, workdir = render_pdf_pages(pdf_path, dpi=dpi)
    total = len(images)

    # 增量写入：每批解析完立即落盘 + flush，中途崩溃也留得下可用的部分讲义。
    try:
        with open(output_md_path, "w", encoding="utf-8") as f:
            title = os.path.splitext(os.path.basename(pdf_path))[0] + _DEFAULT_TITLE_SUFFIX
            f.write(f"# {title}\n\n")
            f.flush()

            for start in range(0, total, pages_per_request):
                batch = images[start:start + pages_per_request]
                first, last = batch[0][0] + 1, batch[-1][0] + 1
                label = str(first) if first == last else f"{first}-{last}"
                print(f"正在处理第 {label} 页（共 {total} 页）...", flush=True)

                text = call_gemini(
                    client, models, [p for _, p in batch], temperature=temperature
                )
                # 注意：切页必须在归一化之前（见 _assemble_blocks 的说明），
                # 所以这里的 normalize 开关是透传进去逐块生效的。
                _write_blocks(f, _assemble_blocks(text, batch, label, normalize))
                f.flush()

        print(f"解析完成！已保存为: {output_md_path}", flush=True)
    finally:
        # 清理临时图片：清理失败绝不该让整个任务失败（Windows 上句柄未释放很常见）。
        for _, img_path in images:
            try:
                if os.path.exists(img_path):
                    os.remove(img_path)
            except OSError:
                pass
        try:
            os.rmdir(workdir)
        except OSError:
            pass

    return output_md_path


# ---------------------------------------------------------------------------
# 9. 连通性自检（替代 notebook 里手敲的那两段试跑）
# ---------------------------------------------------------------------------
# 640x200 的白底黑字测试图（内容："H2O  NaCl  Fe3+   Na2CO3 + 2HCl"）。
# 由 PIL 真实生成并 base64 内联，避免依赖 Pillow 才能自检；
# 不用手搓 PNG —— 尺寸不合法（如 1 像素高）会让 API 直接回
# 400 INVALID_ARGUMENT "Unable to process input image"。
def _png_chunk(tag, payload):
    body = tag + payload
    return struct.pack(">I", len(payload)) + body + struct.pack(">I", zlib.crc32(body))


def make_probe_png(width=256, height=64):
    """用标准库现场生成一张确定性的小 PNG（黑边 + 对角线），不依赖 Pillow。

    为什么不用 base64 内联一张图：那串字面量太长、太容易被编辑器/换行搞坏，
    而这里每行像素都可由代码复算，坏不了。尺寸也必须在合理范围内 ——
    实测 1 像素高的图会被 API 直接回 `400 INVALID_ARGUMENT:
    Unable to process input image`（这也是 notebook 里那张手搓 PNG 的坑）。
    """
    rows = bytearray()
    for y in range(height):
        rows.append(0)  # 每行的 filter type = 0 (None)
        for x in range(width):
            border = x < 3 or y < 3 or x >= width - 3 or y >= height - 3
            diag = abs(x * height - y * width) < height * 2
            rows += b"\x00\x00\x00" if (border or diag) else b"\xff\xff\xff"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # 8bit RGB
    return (b"\x89PNG\r\n\x1a\n"
            + _png_chunk(b"IHDR", ihdr)
            + _png_chunk(b"IDAT", zlib.compress(bytes(rows), 9))
            + _png_chunk(b"IEND", b""))


def _check_one_model(client, model, part):
    """跑一次最小请求，成功返回 (True, 文本)，失败返回 (False, 错误摘要)。"""
    config = {"temperature": 0.0, "max_output_tokens": 256}
    try:
        response = client.models.generate_content(
            model=model,
            contents=[part, "只回答：你能看到这张图吗？图中的几何形状是什么？"],
            config=config,
        )
        text = re.sub(r"\s+", " ", response.text or "").strip()
        return True, text
    except Exception as e:  # noqa: BLE001
        return False, re.sub(r"\s+", " ", str(e))[:300]


def check_api(api_key=None, proxy=None, models=None, image_path=None, mime_type=None):
    """连通性自检：验证 key / 网络 / 代理 / 模型 / 图片输入这几件事。

    默认用 `make_probe_png()` 现场生成的小图；也可以用 `--check-image 真实截图.png`
    换成任意一张真实课件截图，用来确认“图像能不能被正确解码”而不只是“网络通不通”。
    """
    models = models or list(DEFAULT_MODELS)
    proxy = setup_proxy(proxy)
    print(f"代理: {proxy or '（未设置，直连）'}")
    print(f"API Key: ...{resolve_api_key(api_key)[-6:]}")

    if image_path:
        with open(image_path, "rb") as f:
            data = f.read()
        mime = mime_type or ("image/png" if image_path.lower().endswith(".png") else "image/jpeg")
        print(f"测试图: {image_path}（{len(data) / 1024:.1f}KB, {mime}）")
    else:
        data, mime = make_probe_png(), "image/png"
        print(f"测试图: 内置生成 {mime}（{len(data)} 字节）")

    client = build_client(api_key=api_key, proxy=proxy)
    part = {"inline_data": {"mime_type": mime, "data": base64.b64encode(data).decode("ascii")}}

    ok = False
    for model in models:
        print(f"-- 测试 {model} ...", flush=True)
        success, detail = _check_one_model(client, model, part)
        print(f"   {'[OK]  ' + detail if success else '[FAIL] ' + detail}", flush=True)
        ok = ok or success

    if ok:
        print("\n自检通过：API Key / 网络 / 图片输入三者都正常，可以开始转换。")
    else:
        print("\n自检失败：按上面的报错依次排查 ——\n"
              "  ① 'User location is not supported' → **节点/地区问题**，换一个可用出口节点，与 Key 无关；\n"
              "  ② 'API key not valid' / 401 / 403   → Key 无效或没权限（--api-key 或环境变量 GEMINI_API_KEY）；\n"
              "  ③ 'WinError 10060' / 超时           → 没走代理（--proxy http://127.0.0.1:7897）；\n"
              "  ④ 'no longer available' / 404       → 模型名过时（--model 换一个，逗号可写降级链）。")
    return 0 if ok else 1


def build_arg_parser():
    p = argparse.ArgumentParser(
        prog="pdf_to_chemistry_handout_gemini.py",
        description="PDF -> 化学教案 Markdown（Google Gemini API 版）",
    )
    p.add_argument("input_pdf", nargs="?", default="test1.pdf", help="输入 PDF（默认 test1.pdf）")
    p.add_argument("output_md", nargs="?", default=None,
                   help="输出 Markdown（默认 <输入名>_handout_gemini.md）")
    p.add_argument("--model", default=None,
                   help="模型名，可用逗号写降级链（默认 %s）" % ",".join(DEFAULT_MODELS))
    p.add_argument("--api-key", default=None, help="API Key（默认读 GEMINI_API_KEY）")
    p.add_argument("--proxy", default=None, help="HTTP 代理，如 http://127.0.0.1:7897（默认读 HM_PROXY）")
    p.add_argument("--dpi", type=int, default=RENDER_DPI, help=f"渲染 DPI（默认 {RENDER_DPI}）")
    p.add_argument("--pages-per-request", type=int, default=PAGES_PER_REQUEST,
                   help=f"每次请求塞几页（默认 {PAGES_PER_REQUEST}）")
    p.add_argument("--temperature", type=float, default=0.0, help="采样温度（默认 0，转写要确定性）")
    p.add_argument("--pages", default=None, help="只处理指定页，如 1-3,7（页码从 1 开始）")
    p.add_argument("--no-normalize", action="store_true", help="跳过 handout_normalize 后处理")
    p.add_argument("--check", action="store_true", help="只做 API 连通性自检，不转换 PDF")
    p.add_argument("--check-image", default=None,
                   help="自检时改用这张真实图片（png/jpg）替代内置测试图")
    return p


def _parse_page_spec(spec):
    """'1-3,7' -> {1,2,3,7}；返回 None 表示不限。"""
    if not spec:
        return None
    pages = set()
    for chunk in str(spec).split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            a, b = chunk.split("-", 1)
            pages.update(range(int(a), int(b) + 1))
        else:
            pages.add(int(chunk))
    return pages or None


def main(argv=None):
    args = build_arg_parser().parse_args(argv)

    if args.check:
        return check_api(api_key=args.api_key, proxy=args.proxy,
                         models=parse_models(args.model), image_path=args.check_image)

    output_md = args.output_md or (os.path.splitext(args.input_pdf)[0] + "_handout_gemini.md")
    selected = _parse_page_spec(args.pages)

    client = build_client(api_key=args.api_key, proxy=args.proxy)
    models = parse_models(args.model)

    if selected is None:
        convert_pdf_to_handout(
            args.input_pdf, output_md, client=client, models=models,
            dpi=args.dpi, pages_per_request=args.pages_per_request,
            normalize=not args.no_normalize, temperature=args.temperature,
        )
    else:
        # 抽页模式：只渲染指定页再走同一条链路（用于快速试参数，不必等整份 PDF）。
        import shutil

        images, workdir = render_pdf_pages(args.input_pdf, dpi=args.dpi)
        keep = [(n, p) for n, p in images if (n + 1) in selected]
        try:
            convert_selected_pages(keep, output_md, client, models, args)
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    return 0


def convert_selected_pages(images, output_md, client, models, args):
    """--pages 模式：把已渲染的指定页按批送模型并落盘（与主流程同一套切页/归一化逻辑）。"""
    batch_size = max(1, int(args.pages_per_request))
    normalize = not args.no_normalize
    with open(output_md, "w", encoding="utf-8") as f:
        title = os.path.splitext(os.path.basename(args.input_pdf))[0] + _DEFAULT_TITLE_SUFFIX
        f.write(f"# {title}\n\n")
        f.flush()
        for start in range(0, len(images), batch_size):
            batch = images[start:start + batch_size]
            first, last = batch[0][0] + 1, batch[-1][0] + 1
            label = str(first) if first == last else f"{first}-{last}"
            print(f"正在处理第 {label} 页...", flush=True)
            text = call_gemini(client, models, [p for _, p in batch], temperature=args.temperature)
            _write_blocks(f, _assemble_blocks(text, batch, label, normalize))
            f.flush()
    print(f"解析完成！已保存为: {output_md}", flush=True)
    return output_md


if __name__ == "__main__":
    sys.exit(main())
