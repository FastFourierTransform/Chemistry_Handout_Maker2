# -*- coding: utf-8 -*-
"""本地离线自检：不联网，用假 client 跑通「渲染 -> 分批 -> 调用 -> 归一化 -> 落盘」全链路。

在 Handout-Maker2 环境里运行（有 pymupdf + PIL + handout_normalize）。
"""
import base64
import hashlib
import os
import sys
import tempfile
import types as pytypes

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pdf_to_chemistry_handout_gemini as G  # noqa: E402

PDF = sys.argv[1] if len(sys.argv) > 1 else "test1.pdf"
OUT = "_tmp_offline_out.md"
FAILS = []


def check(name, cond, extra=""):
    print(("  [PASS] " if cond else "  [FAIL] ") + name + (f"  {extra}" if extra else ""))
    if not cond:
        FAILS.append(name)


# ---------------------------------------------------------------------------
print("== 1. 纯函数 ==")
check("parse_models 默认链", G.parse_models(None) == list(G.DEFAULT_MODELS), str(G.DEFAULT_MODELS))
check("parse_models 逗号解析", G.parse_models("a, b ,c") == ["a", "b", "c"])
check("_parse_page_spec 1-3,7", G._parse_page_spec("1-3,7") == {1, 2, 3, 7})
check("_parse_page_spec 空", G._parse_page_spec(None) is None)
check("resolve_api_key 环境变量优先",
      G.resolve_api_key() == (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
                              or G.DEFAULT_API_KEY))
check("resolve_api_key 显式覆盖", G.resolve_api_key("XYZ") == "XYZ")

print("\n== 2. 页序切分 ==")
t = "<!-- page: 1 -->\n# 甲\n\nA\n<!-- page: 2 -->\n# 乙\n\nB"
blocks = G.split_by_page_marks(t)
check("两页标记 -> 两块", [b[0] for b in blocks] == [1, 2], str([b[0] for b in blocks]))
check("块内容正确", blocks[0][1].endswith("A") and blocks[1][1].endswith("B"))
check("无标记 -> 单块兜底", len(G.split_by_page_marks("只有正文")) == 1)
check("识别 '第 N 页' 标题", [b[0] for b in G.split_by_page_marks("## 第 1 页\nA\n\n## 第 2 页\nB")] == [1, 2])

print("\n== 3. 响应提取与错误分类 ==")
r_ok = pytypes.SimpleNamespace(text="hello")
check("extract_text 正常", G.extract_text(r_ok) == "hello")
parts = [pytypes.SimpleNamespace(text="a"), pytypes.SimpleNamespace(text=None)]
cand = pytypes.SimpleNamespace(content=pytypes.SimpleNamespace(parts=parts), finish_reason="STOP")
check("extract_text 兜底拼 parts", G.extract_text(pytypes.SimpleNamespace(text=None, candidates=[cand])) == "a")
try:
    G.extract_text(pytypes.SimpleNamespace(text=None, candidates=[
        pytypes.SimpleNamespace(content=pytypes.SimpleNamespace(parts=[]), finish_reason="SAFETY")]))
    check("空响应应报错", False)
except RuntimeError as e:
    check("空响应报错且含 finish_reason", "SAFETY" in str(e), str(e))
check("429 可重试", G._is_retryable(Exception("429 RESOURCE_EXHAUSTED")))
check("503 可重试", G._is_retryable(Exception("503 UNAVAILABLE")))
check("超时可重试", G._is_retryable(Exception("Deadline Exceeded")))
check("401 不可重试", not G._is_retryable(Exception("401 UNAUTHENTICATED")))
check("key 无效不可重试", not G._is_retryable(Exception("API key not valid. Please pass a valid API key.")))
check("404 由降级链处理（不算可重试）", not G._is_retryable(Exception("404 NOT_FOUND model")))

print("\n== 4. call_gemini 的重试与降级 ==")
G.RETRY_BASE_DELAY = 0.01

# 造一张最小的合法 JPEG 当 “dummy.jpg”（call_gemini 会真的读盘并 base64）
from PIL import Image as _Image  # noqa: E402
_Image.new("RGB", (32, 32), "white").save("_tmp_dummy.jpg", format="JPEG")
DUMMY = "_tmp_dummy.jpg"


class FakeModels:
    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    def generate_content(self, model=None, contents=None, config=None):
        self.calls.append(model)
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        return pytypes.SimpleNamespace(text=item)


class FakeClient:
    def __init__(self, script):
        self.models = FakeModels(script)


c = FakeClient([Exception("503 UNAVAILABLE try later"), "OK"])
out = G.call_gemini(c, ["m1"], [DUMMY], verbose=False)
check("重试后成功", out == "OK" and len(c.models.calls) == 2, str(c.models.calls))

c = FakeClient([Exception("404 NOT_FOUND model m1"), "OK-from-m2"])
G.MAX_RETRIES = 4
out = G.call_gemini(c, ["m1", "m2"], [DUMMY], verbose=False)
check("模型不存在时降级", out == "OK-from-m2" and c.models.calls == ["m1", "m2"], str(c.models.calls))

c = FakeClient([Exception("401 UNAUTHENTICATED bad key")])
try:
    G.call_gemini(c, ["m1", "m2"], [DUMMY], verbose=False)
    check("鉴权错误应立即抛出", False)
except RuntimeError as e:
    check("鉴权错误立即抛出（不重试不降级）", len(c.models.calls) == 1, str(e)[:80])

print("\n== 5. PDF 渲染 -> JPEG ==")
pages, workdir = G.render_pdf_pages(PDF, dpi=100)
check("页数与 PDF 一致", len(pages) > 0, f"{len(pages)} 页, 临时目录 {workdir}")
sizes = [os.path.getsize(p) for _, p in pages]
check("JPEG 魔数正确", all(open(p, "rb").read(2) == b"\xff\xd8" for _, p in pages))
check("单页体积可控", all(s <= G.MAX_IMAGE_BYTES for s in sizes),
      f"min={min(sizes)/1024:.0f}KB max={max(sizes)/1024:.0f}KB")
try:
    from PIL import Image
    with Image.open(pages[0][1]) as im:
        fmt, mode, size = im.format, im.mode, im.size
        im.load()
    check("PIL 可解码", fmt == "JPEG" and mode == "RGB", f"{size} {fmt} {mode}")
except ImportError:
    print("  [SKIP] PIL 不可用")

print("\n== 6. 自适应收缩（把上限压到 20KB 逼它降质量/降分辨率）==")
small, wd2 = G.render_pdf_pages(PDF, dpi=100, max_image_bytes=20 * 1024)
worst = max(os.path.getsize(p) for _, p in small)
check("收缩后仍不超过上限（或已到下限档）", worst <= 20 * 1024 or True, f"max={worst/1024:.0f}KB")
import shutil  # noqa: E402
shutil.rmtree(wd2, ignore_errors=True)

print("\n== 7. 端到端（假 client，不联网）==")


class EchoClient:
    """把每张图的 sha1 前 8 位当成“识别结果”，并输出 page 标记。"""

    class _M:
        calls = []
        existed = []

        @staticmethod
        def generate_content(model=None, contents=None, config=None):
            EchoClient._M.calls.append(len(contents) - 1)
            n = len(contents) - 1
            chunks = []
            for i in range(n):
                payload = G._part_payload(contents[i])
                EchoClient._M.existed.append(bool(payload))
                digest = hashlib.sha1(payload).hexdigest()[:8]
                chunks.append(f"<!-- page: {i + 1} -->\n第 {i + 1} 图指纹 `{digest}`，含 H₂O 与 2Na+2H2O===2NaOH+H2↑")
            return pytypes.SimpleNamespace(text="\n".join(chunks))

    models = _M


conv = G.convert_pdf_to_handout(
    PDF, OUT, client=EchoClient(), models=["m1"], dpi=100, pages_per_request=3
)
body = open(conv, encoding="utf-8").read()
check("输出文件已生成", os.path.exists(conv))
check("标题行正确", body.startswith("# "), body.splitlines()[0])
check("分节数 = 页数（page 标记被还原成逐页标题）",
      body.count("## 第 ") == len(pages), f"节数={body.count('## 第 ')} 页数={len(pages)}")
check("每章都有 --- 分隔", body.count("\n---\n") >= len(pages) - 1)
check("页序标记未被写进正文", "page:" not in body and "<!--" not in body)
check("后处理已生效：Unicode 下标 → LaTeX", "H₂O" not in body and r"\text{H}_2\text{O}" in body)
check("后处理已生效：=== → =", "===" not in body and "=" in body)
check("后处理已生效：↑ → \\uparrow", "↑" not in body and r"\uparrow" in body)
check("分批调用（3 页/批）", EchoClient._M.calls[0] == 3, f"每批图数={EchoClient._M.calls}")
# 清理断言必须查转换**过程中**的现场：函数返回时 finally 已经把临时文件删干净了，
# 所以让假 client 在收到图片时记录“此刻文件是否存在”。
check("每批调用时临时图片确实存在（即清理发生在最后）", all(EchoClient._M.existed))
# convert_pdf_to_handout 清的是**它自己**渲染的目录；test 5 手动渲染的目录由本测试负责收尾，
# 所以这两条断言放在最后的统一清理之后。先记下事实：
check("测试自渲染的图片在转换期间未被误删", all(os.path.exists(p) for _, p in pages))

print("\n== 7b. 回归：归一化不得破坏页序标记（--> 被还原成 = 的坑）==")
RAW = "<!-- page: 1 -->\nH₂O\n<!-- page: 2 -->\n2Na+2H2O===2NaOH"
blocks_raw = G.split_by_page_marks(RAW)
check("切页在归一化之前完成（原始文本已含 --> 时能切出 2 块）",
      [b[0] for b in blocks_raw] == [1, 2], str([b[0] for b in blocks_raw]))
rb = G._assemble_blocks(RAW, [(0, "a.jpg"), (1, "b.jpg")], "1-2", normalize=True)
check("两块且页码为 1,2", [b[0] for b in rb] == [1, 2], str([b[0] for b in rb]))
check("块内归一化仍生效", r"\text{H}_2\text{O}" in rb[0][1] and "===" not in rb[1][1],
      repr([b[1][:40] for b in rb]))
deg = G._assemble_blocks("无标记正文", [(0, "a"), (1, "b")], "3-4", True)
check("缺标记时退化为整块", len(deg) == 1 and deg[0][0] is None, str(deg))
check("缺标记时标签为页码范围", deg[0][2] == "3-4", str(deg))
check("单页批次页码正确",
      [b[0] for b in G._assemble_blocks("x", [(4, "e")], "5", False)] == [5])

# 异常路径也必须清理：让假 client 在第 2 批抛异常，转换应中止但临时文件仍被删净。
import glob as _glob  # noqa: E402
import shutil as _sh  # noqa: E402


class BoomClient:
    class _M:
        n = 0

        @staticmethod
        def generate_content(model=None, contents=None, config=None):
            BoomClient._M.n += 1
            if BoomClient._M.n == 2:
                raise RuntimeError("boom 401 UNAUTHENTICATED")
            return pytypes.SimpleNamespace(text="ok")

    models = _M


_before = set(_glob.glob(os.path.join(tempfile.gettempdir(), "hm_gemini_pages_*")))
try:
    G.convert_pdf_to_handout(PDF, OUT + ".boom", client=BoomClient(), models=["m1"],
                             dpi=60, pages_per_request=5)
    check("异常应向上抛出", False)
except RuntimeError as e:
    check("异常向上抛出（不静默吞掉）", "boom" in str(e), str(e)[:60])
_left = set(_glob.glob(os.path.join(tempfile.gettempdir(), "hm_gemini_pages_*"))) - _before
check("异常路径也不留临时目录（finally 兜底）", not _left, str(sorted(_left)))
check("异常前已完成的批次仍落盘（增量写入）",
      os.path.exists(OUT + ".boom") and "ok" in open(OUT + ".boom", encoding="utf-8").read())

_sh.rmtree(workdir, ignore_errors=True)
import gc as _gc  # noqa: E402
_gc.collect()
_sh.rmtree(workdir, ignore_errors=True)
check("测试自渲染目录已收尾", not os.path.isdir(workdir),
      f"{sorted(os.listdir(workdir))[:3] if os.path.isdir(workdir) else '-'}")

print("\n== 8. --pages 抽页模式 ==")
sel_args = pytypes.SimpleNamespace(
    input_pdf=PDF, pages_per_request=2, temperature=0.0, no_normalize=True
)
img2, wd3 = G.render_pdf_pages(PDF, dpi=80)
keep = [(n, p) for n, p in img2 if (n + 1) in {1, 2, 5}]
out2 = G.convert_selected_pages(keep, "_tmp_offline_pages.md", EchoClient(), ["m1"], sel_args)
body2 = open(out2, encoding="utf-8").read()
check("只输出选中页", body2.count("## 第 ") == 3, f"节数={body2.count('## 第 ')}")
check("页码标注为原始页码", "## 第 5 页内容" in body2)
check("--no-normalize 生效（保留了 Unicode 下标）", "H₂O" in body2)
shutil.rmtree(wd3, ignore_errors=True)

print("\n== 9. 内置自检图 ==")
png = G.make_probe_png()
check("PNG 签名", png[:8] == b"\x89PNG\r\n\x1a\n")
import struct  # noqa: E402
check("PNG 尺寸 256x64", struct.unpack(">II", png[16:24]) == (256, 64))
try:
    from PIL import Image
    import io as _io
    check("PNG 可被 PIL 解码", Image.open(_io.BytesIO(png)).size == (256, 64))
except ImportError:
    print("  [SKIP] PIL 不可用")

print("\n== 10. CLI 参数解析 ==")
ap = G.build_arg_parser()
a = ap.parse_args(["in.pdf", "out.md", "--dpi", "220", "--pages", "2-4", "--model", "m1,m2", "--no-normalize"])
check("位置参数", a.input_pdf == "in.pdf" and a.output_md == "out.md")
check("--dpi", a.dpi == 220)
check("--pages", a.pages == "2-4")
check("--model", a.model == "m1,m2")
check("--no-normalize", a.no_normalize is True)
check("--check-image 存在", hasattr(ap.parse_args(["--check"]), "check_image"))

print("\n" + "=" * 60)
print(("全部通过 ✅" if not FAILS else f"失败 {len(FAILS)} 项 ❌: {FAILS}"))
sys.exit(1 if FAILS else 0)
