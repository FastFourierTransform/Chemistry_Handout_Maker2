# -*- coding: utf-8 -*-
"""PDF -> 化学教案 转换器（本地 Qwen2-VL-7B 4-bit 量化）。

用法：
    python pdf_to_chemistry_handout.py [输入.pdf] [输出.md]

依赖环境：conda env "Handout-Maker2"（torch 2.5.1+cu121 / transformers 5.17.0 /
bitsandbytes 0.50.2 / pymupdf）。本机仅一块 NVIDIA GeForce RTX 4070 Laptop GPU（约 8GB），
因此显存预算按 8GB 设计。
"""

import os
import sys
import gc
import tempfile

from handout_normalize import normalize_handout_markdown

# ---------------------------------------------------------------------------
# 1. 环境设置（必须在 import torch 之前设置 CUDA_VISIBLE_DEVICES）
# ---------------------------------------------------------------------------
# 本机只有一块 GPU，逻辑编号为 0。原脚本写死 "1" 会把唯一的显卡隐藏掉，
# 导致 torch.cuda.device_count() == 0，模型无法挂到 GPU。
os.environ["CUDA_VISIBLE_DEVICES"] = os.environ.get("CUDA_VISIBLE_DEVICES", "0")
os.environ["HF_ENDPOINT"] = os.environ.get("HF_ENDPOINT", "https://hf-mirror.com")

import fitz  # PyMuPDF  (noqa: E402)
from PIL import Image  # noqa: E402
import torch  # noqa: E402
from transformers import (  # noqa: E402
    Qwen2VLForConditionalGeneration,
    AutoProcessor,
    BitsAndBytesConfig,
)

MODEL_ID = "Qwen/Qwen2-VL-7B-Instruct"

# 单页像素上限（Qwen2-VL image processor 的 longest_edge）。
# 默认 2359296 ≈ 2000px 宽，可在 8GB 显存下稳定运行且文字/上下标仍清晰。
# 若显存不足可调小（如 1179648），追求更高清晰度可调大（最大 12845056）。
MAX_PIXELS = int(os.environ.get("HM_MAX_PIXELS", "2359296"))

# 渲染 PDF 的 DPI。16:9 幻灯片在 200 DPI 下约 2666x1500，再由处理器按 MAX_PIXELS 缩放。
RENDER_DPI = int(os.environ.get("HM_DPI", "200"))


# ---------------------------------------------------------------------------
# 2. 4-bit 量化配置（约 5~6GB 显存，适配 8GB 的 4070 Laptop）
# ---------------------------------------------------------------------------
def build_quantization_config() -> BitsAndBytesConfig:
    return BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4",
    )


def load_model():
    """加载量化模型与处理器，并设置像素上限。"""
    model = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_ID,
        quantization_config=build_quantization_config(),
        device_map="auto",          # 自动挂载到当前可见 GPU（逻辑 device:0）
        local_files_only=True,      # 模型已缓存到本地，避免联网
        low_cpu_mem_usage=True,
    )
    processor = AutoProcessor.from_pretrained(MODEL_ID, local_files_only=True)

    # 控制单页分辨率上限，避免视觉编码器产生过大的 patch 序列导致 OOM。
    if hasattr(processor, "image_processor") and hasattr(processor.image_processor, "size"):
        processor.image_processor.size["longest_edge"] = MAX_PIXELS

    return model, processor


def get_model_device(model) -> torch.device:
    """获取模型实际运行的设备，避免硬编码 .to('cuda')。"""
    try:
        dev = model.device
    except Exception:
        dev = None
    if dev is None or (isinstance(dev, torch.device) and dev.type == "meta"):
        try:
            dev = next(model.parameters()).device
        except StopIteration:
            dev = torch.device("cpu")
    return dev


# ---------------------------------------------------------------------------
# 3. PDF 页面转图片
# ---------------------------------------------------------------------------
def pdf_to_images(pdf_path, dpi=RENDER_DPI, workdir=None):
    """将 PDF 页面转成 PNG，返回 [(page_index, img_path), ...] 与页数。"""
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"找不到 PDF 文件: {pdf_path}")

    doc = fitz.open(pdf_path)
    workdir = workdir or tempfile.mkdtemp(prefix="hm_pages_")
    images = []
    try:
        for page_num in range(len(doc)):
            page = doc[page_num]
            pix = page.get_pixmap(dpi=dpi)
            img_path = os.path.join(workdir, f"page_{page_num}.png")
            pix.save(img_path)
            images.append((page_num, img_path))
    finally:
        doc.close()
    return images, workdir


# ---------------------------------------------------------------------------
# 4. 单页内容解析
# ---------------------------------------------------------------------------
PROMPT = """你是一个专业的化学讲义整理助手。请将这张化学课件图片的内容转换为结构化的 Markdown 讲义。
要求：
1. 提取所有文字标题、正文和列表，保留清晰的段落结构。
2. **所有化学式与化学方程式必须且只能使用同一种格式：行内 LaTeX（$...$）**。
   元素符号用 \\text{...} 保持正体，上下标用 _ 与 ^（例如 $\\text{H}_2\\text{O}$、$\\text{Fe}^{3+}$、$\\text{SO}_4^{2-}$）。
   禁止使用 Unicode 上下标（如 H₂O、Na⁺），禁止 \\ce{}，禁止 \\[...\\] 与 \\begin{align*} 等公式环境。
3. 化学方程式中的等号必须写作 =，**绝对禁止用 -> 或 → 代替等号**。
   只有带反应条件（加热、点燃、催化剂等）或可逆反应才用箭头：条件写 \\xrightarrow[下方条件]{上方条件}，可逆写 \\rightleftharpoons，
   气体/沉淀符号用 \\uparrow / \\downarrow。
   示例：$\\text{2KClO}_3 \\xrightarrow[\\Delta]{\\text{MnO}_2} \\text{2KCl} + \\text{3O}_2\\uparrow$；
   以及 $2\\text{Na} + 2\\text{H}_2\\text{O} = 2\\text{NaOH} + \\text{H}_2\\uparrow$。
4. 遇到图表或示意图，请在对应位置用 `>[图示: 描述内容]` 标记出提示。
5. 直接输出 Markdown 内容：不要用 ``` 代码块包裹，不要输出任何解释、总结或“请随时告诉我”之类的收尾语。"""


def parse_chemistry_page(model, processor, image_path, max_new_tokens=2048, repetition_penalty=1.15):
    """利用本地大模型解析单页 PPT 内容。"""
    image = Image.open(image_path).convert("RGB")

    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": PROMPT},
            ],
        }
    ]

    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    device = get_model_device(model)
    inputs = processor(text=[text], images=[image], padding=True, return_tensors="pt").to(device)

    with torch.no_grad():
        # repetition_penalty > 1 用于抑制 VLM 贪婪解码时的重复退化（整段反复复读）。
        generated_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            repetition_penalty=repetition_penalty,
            do_sample=False,
        )

    generated_ids_trimmed = [
        out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
    ]
    output_text = processor.batch_decode(
        generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
    )
    # 确定性后处理：剥围栏/去寒暄、统一化学式为行内 LaTeX、等号还原为 =（见 README 7.2/7.3）。
    return normalize_handout_markdown(output_text[0])


# ---------------------------------------------------------------------------
# 5. 主流程
# ---------------------------------------------------------------------------
def convert_pdf_to_handout(pdf_path, output_md_path, model=None, processor=None):
    own_model = model is None
    if own_model:
        model, processor = load_model()

    images, workdir = pdf_to_images(pdf_path)

    # 增量写入：每页解析完立即落盘，长时间批处理中途崩溃也不会丢失已完成的页面。
    try:
        with open(output_md_path, "w", encoding="utf-8") as f:
            f.write(f"# {os.path.basename(pdf_path).replace('.pdf', '')} 课程讲义\n\n")
            for page_num, img_path in images:
                print(f"正在处理第 {page_num + 1} / {len(images)} 页...", flush=True)
                page_md = parse_chemistry_page(model, processor, img_path)
                f.write(f"## 第 {page_num + 1} 页内容\n\n" + page_md + "\n\n---\n\n")
                f.flush()
                # 每页处理完释放显存碎片
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
        print(f"解析完成！已保存为: {output_md_path}", flush=True)
    finally:
        # 清理临时图片
        for _, img_path in images:
            try:
                if os.path.exists(img_path):
                    os.remove(img_path)
            except OSError:
                pass
        try:
            os.rmdir(workdir)
        except OSError:
            pass

    return output_md_path


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    input_pdf = argv[0] if len(argv) > 0 else "test1.pdf"
    output_md = argv[1] if len(argv) > 1 else os.path.splitext(input_pdf)[0] + "_handout.md"
    convert_pdf_to_handout(input_pdf, output_md)


if __name__ == "__main__":
    main()
