# test1 课程讲义

## 第 1 页内容

# 钠元素

### 1. 自然界存在
钠元素在自然界中都以化合物的形式存在。

### 2. 钠的原子结构示意图
![钠的原子结构示意图](image.png)
由此可知钠原子容易失去1个电子，达到最外层8电子的稳定结构。因此$\text{Na}$元素的稳定化合价为+1价，由此也可推出金属钠易失电子，具有强还原性。

---

## 第 2 页内容

# 金属钠

## 物理性质
在常温下, 金属钠为银白色具有金属光泽的固体, 质软, 熔点低, 密度小于水但大于煤油。

## 化学性质
根据钠原子结构示意图可知, 钠元素的稳价是+1价, 所以金属钠(0价)体现极强的还原性, 能与绝大多数的氧化剂反应。

[图示: 钠原子结构示意图]

根据钠原子结构示意图可知, 钠元素的稳价是+1价, 所以金属钠(0价)体现极强的还原性, 能与绝大多数的氧化剂反应。

---

## 第 3 页内容

# 与非金属单质的反应

## (1) 与氧气反应

### ① 与氧气反应

$4Na + O_2 \rightleftharpoons 2Na_2O (\text{白色})$

$2Na + O_2 \stackrel{\triangle}{\longrightarrow} Na_2O_2 (\text{淡黄色})$

注:
i. 钠投入坩埚中, 受热后先熔化, 再燃烧(说明$\text{Na}$的熔点低于着火点). 燃烧时发出黄色火焰, 放出大量的热(放热反应), 生成淡黄色固体.

ii. 这两个反应体现了温度的量变引起质变。铁与氧气的反应也存在温度的量变引起质变，铁在纯氧中燃烧生成黑色的$\text{Fe}_3\text{O}_4$，在常温下缓慢氧化生成$\text{Fe}_2\text{O}_3$。

> [图示: 钠与氧气反应的示意图]
>
> 注: i. 钠投入坩埚中, 受热后先熔化, 再燃烧(说明$\text{Na}$的熔点低于着火点). 燃烧时放出大量热量.
>
> ii. 这个反应体现了温度的量变引起质变。铁与氧气的反应也存在温度的量变引起质变，铁在纯氧中燃烧生成黑色的$\text{Fe}_3\text{O}_4$，在常温下缓慢氧化生成$\text{Fe}_2\text{O}_3$.

---

## 第 4 页内容

# 与非金属单质的反应

## (2) $\text{X}_2($ $\text{F}_2$, $\text{Cl}_2$, $\text{Br}_2$, $\text{I}_2)$

### 反应方程

$2Na + X_{2} \xrightarrow{\triangle} 2NaX$

注:
钠既可以在 $\text{O}_2$中燃烧，又可以在 $\text{Cl}_2$ 中燃烧。由此可知，可燃物与氧化剂（或助燃剂）发生剧烈的发光发热的化学反应叫作燃烧反应。燃烧反应不一定有 $\text{O}_2$参与。

---

$\text{(2) } X_{2}(F_{2}, Cl_{2}, Br_{2}, I_{2})$ $2Na + X_{2} \xrightarrow{\triangle} 2NaX$

注:
钠既可以在 $\text{O}_2$中燃烧，又可以在 $\text{Cl}_2$ 中燃烧。由此可知，可燃物与氧化剂（或助燃剂）发生剧烈的发光发热的化学反应叫作燃烧反应。燃烧反应不一定有 $\text{O}_2$参与。

---

## 第 5 页内容

# 与化合物的反应

## (2) 与化合物的反应

### ①与水(滴有酚酞)

- 化学方程式: $2\text{Na} + 2\text{H}_2\text{O} = 2\text{Na}\text{O}\text{H} + \text{H}_2\uparrow$
- 离子方程式: $2\text{Na} + 2\text{H}_2\text{O} = 2\text{Na}^+ + 2\text{O}\text{H}^- + \text{H}_2\uparrow$
- (现象及解释): 浮—ρ$(\text{H}_2\text{O})$>ρ$(\text{Na})$; 熔—反应放热,且 $\text{Na}$ 的熔点低; 游—反应产生气体; 响—反应剧烈; 红—生成碱性物质)
- 钠与水反应的本质即钠与水电离出的 $\text{H}^+$ 反应

### ②与强酸

- 化学方程式: $2\text{Na} + 2\text{H}^+ = 2\text{Na}^+ + \text{H}_2\uparrow$
- 钠与酸反应的剧烈程度大于钠与水的反应

### ③与盐

#### 水环境 (以 $\text{Cu}\text{S}\text{O}_4$ 溶液为例)

| 实验 | 方程 |
| --- | --- |
| $2\text{Na}$ + $2\text{H}_2\text{O}$ + $\text{Cu}\text{S}\text{O}_4$ = $\text{Na}_2\text{S}\text{O}_4$ + $\text{H}_2\uparrow$ + $\text{Cu}(\text{O}\text{H})_2\downarrow$ | $2\text{Na}$ + $2\text{H}_2\text{O}$ + $\text{Cu}^{2+}$ = $2\text{Na}^+$ + $\text{H}_2\uparrow$ + $\text{Cu}(\text{O}\text{H})_2\downarrow$ |
| 现象:浮、熔、游、响、蓝(生成蓝色絮状沉淀)| |

#### 非水环境 (以熔融 $\text{Ti}\text{Cl}_4$ 为例)

| 实验 | 方程 |
| --- | --- |
| $4\text{Na}$ + $\text{Ti}\text{Cl}_4$ = $4\text{Na}\text{Cl}$ + $\text{Ti}$ | $4\text{Na}$ + $\text{Ti}\text{Cl}_4$ = $4\text{Na}\text{Cl}$ + $\text{Ti}$ |
| 条件:高温 |  |

> [图示: 与化合物的反应]

---
## 第 6 页内容

### 用途

(1) 钠钾合金可用于核反应堆的传热介质, 该用途利用了钠钾合金熔点低, 沸点高, 且导热能力好的性质。

(2) 用作电光源, 制作高压钠灯。该用途利用了钠在高压下能发出具有很强穿透性的黄光。

(3) 冶炼金属

①金属钠具有强还原性, 熔融状态下可以用于制取金属, 如 $4\text{Na} + \text{Ti}\text{Cl}_4 = 4\text{Na}\text{Cl} + \text{Ti}$。

②金属钠的沸点高于金属钾, 控制温度 (K 的沸点 < 反应温度 < 钠的沸点): $\text{Na} + \text{K}\text{Cl} = \text{K}\uparrow + \text{Na}\text{Cl}$。

---

## 第 7 页内容

### 制备

$2NaCl(\text{熔融}) \xrightarrow{\text{电解}} 2Na + Cl_2$

注：电解 $\text{Na}\text{Cl}$ 水溶液不能获得金属钠，因为水电离的 $\text{H}^+$其氧化性强于 $\text{Na}^+($或钠单质与水要反应，水中不可能有金属钠)。

### 保存

密封保存在煤油中。钠着火，不能用水或泡沫灭火器灭火，应该用专用灭火剂或干燥的沙土灭火。

---

## 第 8 页内容

### 下列关于钠的叙述不正确的是 ( )

A. 钠单质只有还原性

B. $\text{Na}^+$只有氧化性，且氧化性强

C. 钠元素在自然界一定是以化合物的形式存在

D. $\text{Na}^+$的最外层电子数为 8

---

## 第 9 页内容

关于金属钠的叙述错误的是( )

A. 金属钠熔点低, 密度和硬度都较小

B. 金属钠保存在煤油中

C. 未用完的金属钠不能放回试剂瓶

D. 钠着火不能用水灭火, 而是用干燥的沙土灭火

---

## 第 10 页内容

# 1.$\text{Na}_2\text{O}$和$\text{Na}_2\text{O}_2$的对比

| 物质 | 氧化钠$(\text{Na}_2\text{O})$ | 过氧化钠$(\text{Na}_2\text{O}_2)$ |
| --- | --- | --- |
| 颜色、状态 | 白色固体 | 淡黄色固体 |
| 类别 | 碱性氧化物 | 过氧化物(不是碱性氧化物) |
| 氧的价态 | −2 (稳价) | −1 (非稳价) |
| 阴、阳离子个数比 | $1(\text{O}^{2-})$: $2(\text{Na}^+)$ | $1(\text{O}_2^-)$: $2(\text{Na}^+)$ |
| 主要化学性质 | 碱性氧化物的通性 | 既有氧化性(强),又有还原性(弱) |
| 常见反应 | 与水 | $\text{Na}_{2}\text{O}+\text{H}_2\text{O} \rightleftharpoons 2\text{Na}^+ + 2\text{OH}^-$ |
| 与$\text{C}\text{O}_2$ | $\text{Na}_{2}\text{O}+\text{CO}_2 \rightleftharpoons \text{Na}_2\text{CO}_3$ |
| 与硫酸 | $\text{Na}_{2}\text{O}+2\text{H}^+ \rightleftharpoons 2\text{Na}^+ + \text{H}_2\text{O}$ |
| 转化 | &nbsp; | $\text{2Na}_{2}\text{O}+\text{O}_2 \overset{\triangle}{=} 2\text{Na}_2\text{O}_2$ |
| 主要用途 | 用于制取少量烧碱 | 强氧化剂、漂白剂、消毒剂、供氧剂 |

> [图示: $\text{Na}_2\text{O}$和$\text{Na}_2\text{O}_2$的对比]

---

### 反应方程式的转化

- **过氧化氢分解生成氧气**

  $\text{2H}_2\text{O}_2 \rightleftharpoons \text{2H}_2\text{O} + \text{O}_2\uparrow$

- **氯酸钾受热分解生成氧气**

  $\text{2KClO}_3 \xrightarrow[\Delta]{\text{MnO}_2} \text{2KCl} + \text{3O}_2\uparrow$

- **碳酸钙高温分解生成二氧化碳**

  $\text{CaCO}_3 \xrightarrow[\Delta]{\text{高温}} \text{CaO} + \text{CO}_2\uparrow$

- **铁丝燃烧生成四氧化三铁**

  $\text{3Fe} + 2\text{O}_2 \xrightarrow{} \text{Fe}_3\text{O}_4$

- **镁条燃烧生成氧化镁**

  $\text{2Mg} + \text{O}_2 \xrightarrow{} 2\text{MgO}$

- **铝箔燃烧生成氧化铝**

  $\text{4Al} + 3\text{O}_2 \xrightarrow{} 2\text{Al}_2\text{O}_3$

- **碳不完全燃烧生成一氧化碳**

  $\text{C} + \text{O}_2 \xrightarrow{\text{点燃}} \text{CO}\downarrow$

- **硫粉燃烧生成二氧化硫**

  $\text{S} + \text{O}_2 \xrightarrow{} \text{SO}_2\uparrow$

- **磷粉燃烧生成五氧化二磷**

  $\text{P} + \text{O}_2 \xrightarrow{} \text{P}_2\text{O}_5\uparrow$

- **氮气与氢气合成氨气**

  $\text{N}_2(g) + 3\text{H}_2(g) \xrightarrow{} 2\text{NH}_3(g)$

- **甲烷与氧气反应生成二氧化碳和水**

  $\text{CH}_4 + 2\text{O}_2 \xrightarrow{} \text{CO}_2 + 2\text{H}_2\text{O}$

- **乙醇与氧气反应生成二氧化碳和水**

  $\text{C}_2\text{H}_6 + 7\text{O}_2 \xrightarrow{} 2\text{CO}_2 + 3\text{H}_2\text{O}$

- **丙烯与氧气反应生成二氧化碳和水**

  $\text{C}_3\text{H}_6 + 9\text{O}_2 \xrightarrow{} 3\text{CO}_2 + 3\text{H}_2\text{O}$

- **丁烷与氧气反应生成二氧化碳和水**

  $\text{C}_4\text{H}_{10} + 13\text{O}_2 \xrightarrow{} 4\text{CO}_2 + 5\text{H}_2\text{O}$

- **乙烯与氧气反应生成二氧化碳和水**

  $\text{C}_2\text{H}_4 + 3\text{O}_2 \xrightarrow{} 2\text{CO}_2 + 2\text{H}_2\text{O}$

- **苯与氧气反应生成二氧化碳和水**

  $\text{C}_6\text{H}_6 + 8\text{O}_2 \xrightarrow{} 6\text{CO}_2 + 6\text{H}_2\text{O}$

- **甲醛与氧气反应生成二氧化碳和水**

  $\text{CH}_2\text{O} + \frac{3}{2}\text{O}_2 \xrightarrow{} \text{CO}_2 + \text{H}_2\text{O}$

- **葡萄糖与氧气反应生成二氧化碳和水**

  $(\text{C}_6\text{H}_{12}\text{O}_6) + 6\text{O}_2 \xrightarrow{} 6\text{CO}_2 + 6\text{H}_2\text{O}$

- **蛋白质与氧气反应生成二氧化碳和水**

  $(\text{C}_m\text{H}_n\text{O}_p\text{N}_q) + (\text{xO}_2) \xrightarrow{} m\text{CO}_2 + n\text{H}_2\text{O} + q\text{NO}_2$

---

## 第 11 页内容

注：$\text{Na}_2\text{O}_2$中O的化合价为−1价，是O的中间价态，$\text{Na}_2\text{O}_2$既有氧化性，又有还原性；由于O的稳价为−2价，所以$\text{Na}_2\text{O}_2$主要体现强氧化性。但物质在化学变化中具体体现什么性质，除了跟自己本身的性质有关外，还要看其反应对象的性质。若$\text{Na}_2\text{O}_2$遇到稳价的$\text{H}_2\text{O}$、$\text{C}\text{O}_2$等，$\text{Na}_2\text{O}_2$发生歧化反应；$\text{Na}_2\text{O}_2$遇强还原剂：$\text{H}_2\text{S}$、$\text{S}\text{O}_2$、$\text{H}\text{I}$等，$\text{Na}_2\text{O}_2$中的O被还原成−2价；$\text{Na}_2\text{O}_2$遇强氧化剂：酸性$\text{K}\text{Mn}\text{O}_4$, $\text{Na}_2\text{O}_2$中的O被氧化成$\text{O}_2$。常考的过氧化物有$\text{H}_2\text{O}_2$、$\text{Na}_2\text{O}_2$、$\text{Ca}\text{O}_2$、过氧乙酸$(\text{C}\text{H}_3\text{C}\text{O}\text{O}\text{O}\text{H})$、过碳酸钠$(\text{Na}_2\text{C}\text{O}_3\cdot\text{H}_2\text{O}_2)$等。

> [图示: 未提供图像描述]

---

## 第 12 页内容

# 2. 漂白性的归纳与总结

| 定义 | 物质与色素(如品红、石蕊等)作用,使其褪色的性质 |
| --- | --- |
| 分类 | 物理变化 | 化学变化 |
| 吸附漂白 | $\text{H}\text{Cl}\text{O}$、$\text{H}_2\text{O}_2$ | 氧化漂白 |
| 代表物质 | 活性炭 | 大多数色素 |

## 问题解答

### (一)
- **定义**: 物质与色素(如品红、石蕊等)作用,使其褪色的性质。

### (二)
- **分类**
  - **物理变化**: 吸附漂白
    - **代表物质**: 活性炭
      - **漂白对象**: 大多数色素
  - **化学变化**: 氧化漂白
    - **代表物质**: $\text{H}\text{Cl}\text{O}$、$\text{H}_2\text{O}_2$
      - **漂白对象**: 大多数色素

---

## 第 13 页内容

# 3. 类比和对比方法的合理使用

$\text{Na}_2\text{O}_2$与稳定的酸性氧化物$\text{C}\text{O}_2$发生歧化反应(氧元素化合价变化遵循“邻价”规律)，产物有$\text{O}_2$。

该反应中每消耗1份$\text{Na}_2\text{O}_2$转移1份电子。但$\text{Na}_2\text{O}_2$与同样是酸性氧化物的$\text{S}\text{O}_2$发生的却是一般氧化还原反应(氧元素化合价变化遵循稳价规律)，产物没有$\text{O}_2$，该反应中每消耗1份$\text{Na}_2\text{O}_2$转移2份电子；因为$\text{S}\text{O}_2$有强还原性。由此可知，学习元素化合物的性质时，不仅要利用“类比法”，也要使用“对比法”。

---

## 第 14 页内容

### 关于钠的氧化物

#### 选项分析

A. $\text{Na}_2\text{O}$ 和 $\text{Na}_2\text{O}_2$ 与水反应均生成$\text{Na}\text{O}\text{H}$，二者均为碱性氧化物。

B. $\text{Na}_2\text{O}_2$ 中阴、阳离子个数比为 1:1。

C. 过量金属钠与 1 个 $\text{O}_2$ 充分反应，无论生成 $\text{Na}_2\text{O}$，还是生成 $\text{Na}_2\text{O}_2$，转移电子数均为 2 个。

D. $\text{Na}_2\text{O}$、$\text{Na}_2\text{O}_2$ 分别与 $\text{S}\text{O}_2$ 的反应均为化合反应。

---

根据以上选项，正确的描述是：

- A. 错误。$\text{Na}_2\text{O}$ 是碱性氧化物，而 $\text{Na}_2\text{O}_2$ 不是碱性氧化物。
- B. 正确。$\text{Na}_2\text{O}_2$ 中阴离子 $(\text{O}^{2-})$ 和阳离子 $(\text{Na}^+)$ 的个数比确实是 1:1。
- C. 正确。过量金属钠与氧气充分反应时，无论是生成 $\text{Na}_2\text{O}$ 还是生成 $\text{Na}_2\text{O}_2$，转移的电子数都是 2 个。
- D. 错误。$\text{Na}_2\text{O}$ 与 $\text{S}\text{O}_2$ 反应不是化合反应，而是复分解反应；而 $\text{Na}_2\text{O}_2$ 与 $\text{S}\text{O}_2$ 反应也不是化合反应，因为产物中还有其他物质参与反应。

因此，正确答案是 B 和 C。

---

## 第 15 页内容

### 下列化学方程式或离子方程式书写正确的是( )

A. $\text{Na}$与水反应的化学方程式为$\text{Na}+\text{H}_2\text{O}$ = $\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$

B. $\text{Na}_2\text{O}_2$与水反应的离子方程式为$2\text{O}^{2-}+$ $2\text{H}_2\text{O}$ = $4\text{O}\text{H}^-+$ $\text{O}_2\uparrow$

C. $\text{Na}_2\text{O}_2$与$\text{C}\text{O}_2$反应的化学方程式为$2\text{Na}_2\text{O}_2+$ $2\text{C}\text{O}_2$ = $2\text{Na}_2\text{C}\text{O}_3+$ $\text{O}_2$

D. $\text{Na}_2\text{O}_2$与稀$\text{H}_2\text{S}\text{O}_4$反应的离子方程式为$2\text{Na}_2\text{O}_2+$ $2\text{H}_2\text{S}\text{O}_4$ = $4\text{Na}^++$ $2\text{S}\text{O}_4^{2-}+$ $2\text{H}_2\text{O}+$ $\text{O}_2\uparrow$

---
