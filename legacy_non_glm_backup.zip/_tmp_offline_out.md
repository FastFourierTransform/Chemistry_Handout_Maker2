# test1 课程讲义

## 第 1 页内容

第 1 图指纹 `9d92e8c8`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 2 页内容

第 2 图指纹 `5c6a6b25`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 3 页内容

第 3 图指纹 `bf07fd74`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 4 页内容

第 1 图指纹 `bd7b0d09`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 5 页内容

第 2 图指纹 `78c31c8a`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 6 页内容

第 3 图指纹 `5a9fbbce`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 7 页内容

第 1 图指纹 `69824884`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 8 页内容

第 2 图指纹 `e749775f`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 9 页内容

第 3 图指纹 `7282e4aa`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 10 页内容

第 1 图指纹 `e56f8eb3`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 11 页内容

第 2 图指纹 `04cc5dcb`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 12 页内容

第 3 图指纹 `53d4dc1e`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 13 页内容

第 1 图指纹 `22470660`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 14 页内容

第 2 图指纹 `bb5ee9ca`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

## 第 15 页内容

第 3 图指纹 `23207448`，含 $\text{H}_2\text{O}$ 与 2Na+2H2O=$2\text{Na}\text{O}\text{H}+\text{H}_2\uparrow$


---

